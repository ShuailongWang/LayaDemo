﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestCude : MonoBehaviour
{
    public void ShowMsg() {
    	
    }

    public void ShowMsgValue(int value) {
    	
    }
}
